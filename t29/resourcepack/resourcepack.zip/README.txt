Текстур пак состоит из:
Half_Life_1.11
HL2_TAZIK29_by_DiXiao_1.16.5 (В него входят :
Модели от DiXiao
1 - модель от magicgt
2 - модели с NPC от CMD28
)

+ Звуки от Mr.Dyrhlak

+ Ачивки от SanyaSho

+ Гравити ган от Amanikton